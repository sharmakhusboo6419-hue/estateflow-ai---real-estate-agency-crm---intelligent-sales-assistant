/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LeadsPipeline } from './components/CRM/LeadsPipeline';
import { LeadDetailModal } from './components/CRM/LeadDetailModal';
import { NewLeadModal } from './components/CRM/NewLeadModal';
import { AIChatSimulator } from './components/Chat/AIChatSimulator';
import { ViewingScheduler } from './components/Calendar/ViewingScheduler';
import { FollowUpHub } from './components/FollowUp/FollowUpHub';
import { PropertyCatalog } from './components/Properties/PropertyCatalog';
import { HowItWorksModal } from './components/Guide/HowItWorksModal';

import {
  INITIAL_PROPERTIES,
  INITIAL_LEADS,
  INITIAL_APPOINTMENTS,
  INITIAL_CHAT_MESSAGES,
  INITIAL_FOLLOWUPS,
} from './data/mockData';

import { Lead, Property, AppointmentSlot, FollowUpActivity, PipelineStage } from './types/realEstate';
import { Sparkles, CheckCircle2, Flame } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'crm' | 'chat' | 'calendar' | 'followup' | 'properties' | 'guide'
  >('crm');

  const [leads, setLeads] = useState<Lead[]>(() => {
    const saved = localStorage.getItem('estateflow_leads');
    return saved ? JSON.parse(saved) : INITIAL_LEADS;
  });

  const [properties] = useState<Property[]>(INITIAL_PROPERTIES);

  const [appointments, setAppointments] = useState<AppointmentSlot[]>(() => {
    const saved = localStorage.getItem('estateflow_appointments');
    return saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
  });

  const [followUpActivities, setFollowUpActivities] = useState<FollowUpActivity[]>(() => {
    const saved = localStorage.getItem('estateflow_followups');
    return saved ? JSON.parse(saved) : INITIAL_FOLLOWUPS;
  });

  const [selectedLeadForDossier, setSelectedLeadForDossier] = useState<Lead | null>(null);
  const [selectedPropertyForChat, setSelectedPropertyForChat] = useState<Property>(INITIAL_PROPERTIES[0]);
  const [activeChatLead, setActiveChatLead] = useState<Lead | null>(INITIAL_LEADS[0]);
  const [isNewLeadModalOpen, setIsNewLeadModalOpen] = useState(false);
  const [hasGeminiKey, setHasGeminiKey] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('estateflow_leads', JSON.stringify(leads));
  }, [leads]);

  useEffect(() => {
    localStorage.setItem('estateflow_appointments', JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem('estateflow_followups', JSON.stringify(followUpActivities));
  }, [followUpActivities]);

  // Check backend health
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data.hasGeminiKey === 'boolean') {
          setHasGeminiKey(data.hasGeminiKey);
        }
      })
      .catch((e) => console.log('Health check notice:', e));
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Lead update handler
  const handleUpdateLead = (updatedLead: Lead) => {
    setLeads((prev) => prev.map((l) => (l.id === updatedLead.id ? updatedLead : l)));
    if (selectedLeadForDossier?.id === updatedLead.id) {
      setSelectedLeadForDossier(updatedLead);
    }
  };

  // Update stage handler
  const handleUpdateLeadStage = (leadId: string, newStage: PipelineStage) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, stage: newStage } : l))
    );
    showToast(`Lead moved to ${newStage}`);
  };

  // Add new lead handler
  const handleAddLead = (newLead: Lead) => {
    setLeads((prev) => [newLead, ...prev]);
    showToast(`New client ${newLead.name} added as ${newLead.temperature} lead!`);
  };

  // Add appointment handler
  const handleAddAppointment = (newApp: AppointmentSlot) => {
    setAppointments((prev) => [newApp, ...prev]);
    showToast(`Viewing appointment booked for ${newApp.date} at ${newApp.time}!`);
  };

  // Update appointment status
  const handleUpdateAppointmentStatus = (id: string, status: AppointmentSlot['status']) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status } : a))
    );
    showToast(`Appointment status changed to ${status}`);
  };

  // Add follow-up activity
  const handleAddFollowUp = (activity: FollowUpActivity) => {
    setFollowUpActivities((prev) => [activity, ...prev]);
    showToast(`Follow-up dispatched via ${activity.channel}`);
  };

  // Simulate an inbound high-intent buyer texting the agency
  const handleSimulateInboundLead = () => {
    const simulatedNames = [
      'Vikram & Ananya Patel',
      'Sterling Vance Partners',
      'Jessica & Mark Sterling',
      'Harrison Forbes, Esq.',
    ];
    const pickedName = simulatedNames[Math.floor(Math.random() * simulatedNames.length)];
    const targetProp = properties[Math.floor(Math.random() * 2)]; // pick luxury villa or penthouse

    const newInbound: Lead = {
      id: `lead-inbound-${Date.now()}`,
      name: pickedName,
      email: `${pickedName.toLowerCase().replace(/[^a-z]/g, '')}@luxurygroup.com`,
      phone: '+1 (555) 790-8841',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=256&q=80',
      budget: 1850000,
      temperature: 'Hot',
      stage: 'AI Engaged',
      timeline: 'Immediate (< 30 days, Cash Ready)',
      preferredLocation: targetProp.location,
      preferredPropertyType: targetProp.propertyType,
      interestedPropertyId: targetProp.id,
      preApproved: true,
      aiScore: 96,
      aiSummary: `New WhatsApp inbound inquiring on ${targetProp.title}. Budget $1.85M detected. AI categorized as HOT and prepared available weekend viewing slots!`,
      temperatureRationale: 'Liquid budget >$1M and immediate purchasing timeframe. AI auto-assigned to Senior Broker.',
      lastContactAt: 'Just now',
      unreadCount: 1,
      notes: [`Auto-captured from WhatsApp property ad. Lead inquiring on ${targetProp.title}.`],
      tags: ['WhatsApp Inbound', 'Hot Buyer', 'Cash Ready'],
      assignedAgent: targetProp.agentName,
      createdAt: new Date().toISOString(),
    };

    setLeads((prev) => [newInbound, ...prev]);
    setSelectedPropertyForChat(targetProp);
    setActiveChatLead(newInbound);
    showToast(`🔥 INBOUND LEAD DETECTED: ${pickedName} ($1.85M) auto-classified as HOT!`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        leads={leads}
        onSimulateInboundLead={handleSimulateInboundLead}
        hasGeminiKey={hasGeminiKey}
      />

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-5 z-50 animate-in slide-in-from-top duration-300">
          <div className="bg-slate-900 border border-amber-500/50 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 text-xs font-semibold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Main View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'crm' && (
          <LeadsPipeline
            leads={leads}
            properties={properties}
            onSelectLead={(lead) => setSelectedLeadForDossier(lead)}
            onUpdateLeadStage={handleUpdateLeadStage}
            onOpenNewLeadModal={() => setIsNewLeadModalOpen(true)}
            onStartChatWithLead={(lead) => {
              setActiveChatLead(lead);
              const prop = properties.find((p) => p.id === lead.interestedPropertyId) || properties[0];
              setSelectedPropertyForChat(prop);
              setActiveTab('chat');
            }}
          />
        )}

        {activeTab === 'chat' && (
          <AIChatSimulator
            properties={properties}
            selectedProperty={selectedPropertyForChat}
            onSelectProperty={(prop) => setSelectedPropertyForChat(prop)}
            activeLead={activeChatLead}
            onLeadUpdated={handleUpdateLead}
            onAppointmentBooked={handleAddAppointment}
            hasGeminiKey={hasGeminiKey}
          />
        )}

        {activeTab === 'calendar' && (
          <ViewingScheduler
            appointments={appointments}
            leads={leads}
            properties={properties}
            onAddAppointment={handleAddAppointment}
            onUpdateAppointmentStatus={handleUpdateAppointmentStatus}
            preselectedLead={activeChatLead}
          />
        )}

        {activeTab === 'followup' && (
          <FollowUpHub
            leads={leads}
            properties={properties}
            followUpActivities={followUpActivities}
            onAddFollowUp={handleAddFollowUp}
            preselectedLead={activeChatLead}
          />
        )}

        {activeTab === 'properties' && (
          <PropertyCatalog
            properties={properties}
            onSelectPropertyForChat={(prop) => {
              setSelectedPropertyForChat(prop);
              setActiveTab('chat');
            }}
          />
        )}

        {activeTab === 'guide' && (
          <HowItWorksModal
            onNavigateTab={(tab) => setActiveTab(tab)}
            onSimulateLead={handleSimulateInboundLead}
          />
        )}
      </main>

      {/* Lead Dossier Detail Modal */}
      <LeadDetailModal
        lead={selectedLeadForDossier}
        onClose={() => setSelectedLeadForDossier(null)}
        properties={properties}
        appointments={appointments}
        chatHistory={[]}
        onUpdateLead={handleUpdateLead}
        onSuggestSlots={(lead) => {
          setActiveChatLead(lead);
          setActiveTab('calendar');
        }}
        onOpenChatWithLead={(lead) => {
          setActiveChatLead(lead);
          const prop = properties.find((p) => p.id === lead.interestedPropertyId) || properties[0];
          setSelectedPropertyForChat(prop);
          setActiveTab('chat');
        }}
        onGenerateFollowUp={(lead) => {
          setActiveChatLead(lead);
          setActiveTab('followup');
        }}
      />

      {/* Manual Lead Entry Modal */}
      <NewLeadModal
        isOpen={isNewLeadModalOpen}
        onClose={() => setIsNewLeadModalOpen(false)}
        properties={properties}
        onAddLead={handleAddLead}
      />
    </div>
  );
}
