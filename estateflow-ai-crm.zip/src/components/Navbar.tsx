import React from 'react';
import {
  Building2,
  Users,
  MessageSquare,
  Calendar,
  Send,
  HelpCircle,
  Flame,
  Sun,
  Snowflake,
  UserPlus,
  Sparkles,
  Bot,
  Download,
} from 'lucide-react';
import { Lead } from '../types/realEstate';

interface NavbarProps {
  activeTab: 'crm' | 'chat' | 'calendar' | 'followup' | 'properties' | 'guide';
  setActiveTab: (tab: 'crm' | 'chat' | 'calendar' | 'followup' | 'properties' | 'guide') => void;
  leads: Lead[];
  onSimulateInboundLead: () => void;
  hasGeminiKey: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  leads,
  onSimulateInboundLead,
  hasGeminiKey,
}) => {
  const hotCount = leads.filter((l) => l.temperature === 'Hot').length;
  const warmCount = leads.filter((l) => l.temperature === 'Warm').length;
  const coldCount = leads.filter((l) => l.temperature === 'Cold').length;

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-xl">
      {/* Top Banner with Agency Stats & Real-time AI Badge */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Agency Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-amber-200 bg-clip-text text-transparent">
                  EstateFlow AI
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded">
                  Agency OS
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                AI Sales Chatbot • Lead Qualification CRM • Auto Follow-ups
              </p>
            </div>
          </div>

          {/* Quick Metrics & Simulated Inbound Trigger */}
          <div className="flex items-center gap-3">
            {/* Live Lead Temperature Tally */}
            <div className="hidden md:flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 rounded-lg p-1 text-xs">
              <span className="flex items-center gap-1 px-2 py-1 rounded bg-rose-500/20 text-rose-300 font-semibold border border-rose-500/30">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                Hot ({hotCount})
              </span>
              <span className="flex items-center gap-1 px-2 py-1 rounded bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                Warm ({warmCount})
              </span>
              <span className="flex items-center gap-1 px-2 py-1 rounded bg-sky-500/20 text-sky-300 font-semibold border border-sky-500/30">
                <Snowflake className="w-3.5 h-3.5 text-sky-400" />
                Cold ({coldCount})
              </span>
            </div>

            {/* AI Engine Status Indicator */}
            <div className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
              <Bot className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span className="hidden lg:inline">
                {hasGeminiKey ? 'Gemini 3.8 Flash' : 'AI Sales Assistant Active'}
              </span>
            </div>

            {/* Download Project ZIP button */}
            <a
              href="/api/download-zip"
              download="estateflow-ai-crm.zip"
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
              title="Download clean project zip file to push to GitHub"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Download ZIP</span>
            </a>

            {/* Test Simulation Button */}
            <button
              onClick={onSimulateInboundLead}
              className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-semibold shadow-md shadow-amber-500/20 transition-all hover:scale-105 active:scale-95 cursor-pointer"
              title="Simulate a new potential buyer texting the agency about a luxury property"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              <span className="hidden sm:inline">Simulate Inbound Lead</span>
              <span className="sm:hidden">+ Lead</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto py-1 border-t border-slate-800/80 scrollbar-none">
          <button
            onClick={() => setActiveTab('crm')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'crm'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            CRM Pipeline & Leads
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'chat'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            AI Chatbot Simulator
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'calendar'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Viewing Slots & Calendar
          </button>

          <button
            onClick={() => setActiveTab('followup')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'followup'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Send className="w-4 h-4" />
            AI Automated Follow-up
          </button>

          <button
            onClick={() => setActiveTab('properties')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'properties'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Building2 className="w-4 h-4" />
            Property Inventory ({6})
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`flex items-center gap-2 px-3 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'guide'
                ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shadow-inner'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-indigo-400" />
            How It Works & System Tour
          </button>
        </div>
      </div>
    </header>
  );
};
